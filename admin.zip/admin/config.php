<?php
// Database connection settings
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "cac";

// Initialize connection and display error message if failed
$conn = @new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    // In a production environment, never expose the connect_error
    die("Database connection failed. Please check your credentials: " . $conn->connect_error);
}

// Set character set
$conn->set_charset("utf8");

?>
